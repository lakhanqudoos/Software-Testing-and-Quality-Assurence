# Software Quality Engineering Lab 07
## Browser Automation Using Selenium with Python

**Course:** Software Quality Engineering  
**Lab:** 07 — Browser Automation  
**Tool:** Selenium WebDriver  
**Programming Language:** Python  
**Browser:** Mozilla Firefox  
**IDE:** Visual Studio Code

### 1. Introduction
This lab focuses on browser automation using Selenium WebDriver with Python. It demonstrates how to automate browser operations, navigate between websites, retrieve page information, use browser history, refresh pages, and close browser sessions.

### 2. Requirements
- Python 3
- Selenium WebDriver
- Mozilla Firefox
- Visual Studio Code

### 3. Project Structure
```text
SQA-Lab07/
├── Demonstrations/
│   ├── basic_browser_navigation.py
│   └── browser_window_and_page_info.py
├── Practical Exercises/
│   ├── multiple_website_navigation.py
│   ├── browser_history_navigation.py
│   ├── refresh_verification.py
│   └── complete_navigation_test.py
├── Execution Evidence/
│   ├── 01_Basic_Browser_Navigation/
│   ├── 02_Browser_Window_Page_Info/
│   ├── 03_Multiple_Website_Navigation/
│   ├── 04_Browser_History_Navigation/
│   ├── 05_Refresh_Verification/
│   └── 06_Complete_Navigation_Test/
└── README.md
```

### 4. Installation
Install Selenium using:

```bash
python -m pip install selenium
```

### 5. Lab Tasks

**Demonstrations**
1. Basic Browser Navigation — opening websites, retrieving page information, back, forward, refresh, and closing the browser.
2. Browser Window and Page Information — maximizing the browser and retrieving the current URL and page title.

**Practical Exercises**
1. Multiple Website Navigation
2. Browser History Navigation
3. Refresh Verification
4. Complete Navigation Test

### 6. Execution
Run the Python files from the project root using:

```bash
python "Demonstrations/basic_browser_navigation.py"
```

Replace the filename with the script you want to execute.

### 7. Execution Evidence
The `Execution Evidence` directory contains screenshots of browser activity and terminal output for the practical exercises.

### 8. Conclusion
This lab provided practical experience with Selenium WebDriver and Python for browser automation. It covered essential browser navigation operations and demonstrated how automated scripts can interact with web browsers.